﻿# Client (React)

This is the frontend for the Fullstack Project Management System.

## Run
cd client
npm install
npm start

## Notes
- The backend runs separately (see the root README).
- API requests are proxied to the backend server (see client/package.json).
